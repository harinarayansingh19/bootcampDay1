import psycopg2
connection = psycopg2.connect(database="postgres", user="root", password="root")
cursor = connection.cursor()
cursor.execute("CREATE TABLE registration( fname varchar (10), lname varchar (10), email varchar (15), phoneno int (10), country varchar (10), currentcity varchar (10))")

query = 'INSERT INTO `registration`  VALUES (fName,lName,email,phoneno,country,currentcity)'
cursor.execute(query,(form['fName'], form['lName'],form['email'],form['phoneno'],form['country'],form['currentcity']) )
connection.commit();
 
def view():
        {
        cursor.execute("SELECT fName,lName,email,phoneno,country,currentcity from registration")
        rows = cursor.fetchall()
        for row in rows:
        print  "fName = ", row[0]
        print  "lName = ", row[1]
        print  "email = ", row[2]
        print  "phoneno = ", row[3],
        print   "country = ",row[4],
        print   "currentcity = ", row[5], "\n"
        }